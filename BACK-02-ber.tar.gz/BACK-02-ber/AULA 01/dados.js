//criar um array de nomes
let nomes=["Admilson", "Berenilda", "Ceciliano"];

let frutas=[" amora", "banana", "caqui"];

//module.exports =nomes;
//module.exports =frutas;

function Soma(n1,n2){
    return n1+n2
};

module.exports={
    nomes,
    frutas,
    Soma
};