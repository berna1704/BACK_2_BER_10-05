console.log(" nomes");


//para importar os nomes que estao no arquivo dados.js
let {nomes, frutas, Soma} =require("./dados");
//console.log(pessoas);
//console.log(pessoas[0]);

console.log(nomes);
console.log(frutas);
console.log(Soma(13,7));