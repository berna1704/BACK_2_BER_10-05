//modulo através do móulo require
//manipular modulo os (operatons system)

const os = require(" os");

console.log(os.cpus());

console.log(os.cpu[0]);